from .cnn import CNN_KERAS_A
from .cnn import CNN_KERAS_B
from .xception import XCEPTION_MINI
from .resnet import RESNET_V2
from .autoencoder import CNN_AUTOENCODER
from .mlp import MLP_A
