# Hand detection example

To test the live hand detection from camera, run:
```py
python demo.py
```

To test the hand detection with pose estimation and hand closure classification, run:
```py
python demo_image.py
```
