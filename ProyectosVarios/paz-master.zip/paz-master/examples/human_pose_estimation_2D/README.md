### This example detects 2d human pose from an image.

To test the live human pose detection from camera, run:
```py
python demo.py
```

To test the human pose detection on image, run:
```py
python demo_image.py
```

The output image with human pose skeleton will be saved to *output/result.jpg*.
