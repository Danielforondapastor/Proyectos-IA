# Prototypical networks implementation

## Dataset
Download the dataset calling:

    `./download_omniglot.sh`

## Training
Train dataset:
    `python train.py`
