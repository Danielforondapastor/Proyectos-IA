Please install kaggle python module to automatically download datasets

Make sure to have an account and have set up the API token

And to have accepted the rules of the competition (you would recieve a 403 error in case you have not)

```bash
kaggle competitions download -c facial-keypoints-detection
```

