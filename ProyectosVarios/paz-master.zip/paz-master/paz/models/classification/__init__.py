from .xception import build_xception
from .xception import MiniXception
from .protonet import ProtoEmbedding
from .protonet import ProtoNet
from .cnn2Plus1 import CNN2Plus1D
from .vvad_lrs3 import VVAD_LRS3_LSTM
